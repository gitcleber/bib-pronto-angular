import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
// import { CadernoCreateComponent } from './components/caderno/create/caderno-create.component';
// import { CadernoEditComponent } from './components/caderno/edit/caderno-edit.component';
// import { CadernoIndexComponent } from './components/caderno/index/caderno-index.component';
// import { DoceCreateComponent } from './components/doce/create/doce-create.component';
// import { DoceEditComponent } from './components/doce/edit/doce-edit.component';
// import { DoceIndexComponent } from './components/doce/index/doce-index.component';
import { HomeComponent } from './components/home/home.component';

const routes: Routes = [
    {path: '', pathMatch:'full', redirectTo: 'home'},
    {path: 'home', component: HomeComponent},
    {path: 'cadernos', loadChildren: () => import('./components/caderno/caderno.module').then(c => c.CadernoModule)},
    {path: 'doces', loadChildren: () => import('./components/doce/doce.module').then(d => d.DoceModule)},

    // {path: 'caderno-index', component: CadernoIndexComponent},
    // {path: 'caderno-edit/:id', component: CadernoEditComponent},
    // {path: 'caderno-create', component: CadernoCreateComponent},
    // {path: 'doce-index', component: DoceIndexComponent},
    // {path: 'doce-create', component: DoceCreateComponent},
    // {path: 'doce-edit/:id', component: DoceEditComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
