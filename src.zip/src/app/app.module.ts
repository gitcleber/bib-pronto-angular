import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
// import { CadernoEditComponent } from './components/caderno/edit/caderno-edit.component';
// import { CadernoCreateComponent } from './components/caderno/create/caderno-create.component';
// import { CadernoIndexComponent } from './components/caderno/index/caderno-index.component';
// import { DoceIndexComponent } from './components/doce/index/doce-index.component';
// import { DoceCreateComponent } from './components/doce/create/doce-create.component';
import { HttpClientModule } from '@angular/common/http';
// import { FormsModule } from '@angular/forms';
// import { DoceEditComponent } from './components/doce/edit/doce-edit.component';
import { HomeComponent } from './components/home/home.component';
// import { CadernoModule } from './components/caderno/caderno.module';
// import { DoceModule } from './components/doce/doce.module';

@NgModule({
  declarations: [
    AppComponent,
    // CadernoCreateComponent,
    // CadernoIndexComponent,
    // CadernoEditComponent,
    // DoceIndexComponent,
    // DoceCreateComponent,
    // DoceEditComponent,
    HomeComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    // FormsModule,
    // CadernoModule,
    // DoceModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
