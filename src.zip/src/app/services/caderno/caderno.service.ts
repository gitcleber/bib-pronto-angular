import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Caderno } from 'src/app/model/caderno.model';
import {HttpClient} from '@angular/common/http'

@Injectable({
  providedIn: 'root'
})
export class CadernoService {

  private endpoint: string = "https://localhost:44393/api/cadernos/";

  constructor(private request: HttpClient) {
    // console.log("CadernoService.construtor");
   }

   //Create
   post(caderno: Caderno): Observable<Caderno>{
    // console.log("CadernoService.Save");
     //const endpoint: string = "https://localhost:44393/api/cadernos/";

     return this.request.post<Caderno>(this.endpoint, caderno);
   }

   //Read
   getAll(): Observable<Caderno[]>{
    //  console.log("CadernoService.getAll");
     //const endpoint: string = "https://localhost:44393/api/cadernos/";
     return this.request.get<Caderno[]>(this.endpoint);
   }
   getById(id:number): Observable<Caderno>{
    const endpoint: string = this.endpoint+id; //"https://localhost:44393/api/cadernos/" +id;
    // return this.request.get<Caderno>(endpoint);
    console.log(endpoint)
    return this.request.get<Caderno>(endpoint);
   }
   
   getByParam(titulo: string):Observable<Caderno[]>{
    const endpoint: string = this.endpoint+'?titulo=' + titulo;
    return this.request.get<Caderno[]>(endpoint);
   }

   //Update
   put(caderno: Caderno): Observable<Caderno>{
    const endpoint: string = "https://localhost:44393/api/cadernos/" +caderno.Id;
    return this.request.put<Caderno>(endpoint,caderno);

   }
   
   //Delete
   delete(id: number): Observable<Caderno>{
    const endpoint: string = "https://localhost:44393/api/cadernos/"+ id ;
    return this.request.delete<Caderno>(endpoint);
   }

//   //teste converter um objetoObservable para array
//   private extractData(res: Response) {
//     let body = res.json();
//     return body.data || {};
// }

}
